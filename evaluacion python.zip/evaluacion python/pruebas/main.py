#2. Agregar nuevo jugador: 1
#    a. Diccionario: Permitir al usuario ingresar la información de un nuevo jugador, incluyendo
#    nombre, ranking mundial, servicio, revés, volea, movimiento y condición física. (Estos
#    valores deben ser flotantes)
#    b. Lista: Almacenar la información del nuevo jugador en una lista. 2
jugadores = []
equipo1 = []
equipo2 = []
def agregar_jugador(equipo1,equipo2):
    print("""
1 = agregar jugador al equipo 1
2 = agregar jugador al equipo 2
""")
    opcion = input("a cual equipo le gustaria agregar el jugador?: ")
    if opcion == "1":
        jugadores_ingresar = int(input("cuantos jugadores desea agregar (valor numerico entero): "))
        for i in range(jugadores_ingresar):
            jugador = {}
            nombre = input("ingrese el nombre del jugador: ")
            ranking_mundial = float(input("ingrese el ranking del jugador (valor flotante): "))
            servicio = float(input("ingrese la estadistica de servicio (solo se aceptan valores flotantes): "))
            reves = float(input("ingrese la estadistica de reves (solo se aceptan valores flotantes): "))
            volea = float(input("ingrese la estadistica de volea(solo se aceptan valores flotantes): ")) 
            movimiento = float(input("ingrese la estadistica de movimiento(solo se aceptan valores flotantes): "))  
            condicion_fisica = input("cual es su condicion fisica?: ")

            jugador[nombre] = {
                "ranking mundial": ranking_mundial,
                "servicio" : servicio,
                "reves": reves,
                "volea": volea,
                "movimiento": movimiento,
                "condicion fisica": condicion_fisica
            }
            equipo1.append(jugador)
            jugadores.append(jugador)
            return equipo1, jugadores
    elif opcion == "2":
        jugadores_ingresar = int(input("cuantos jugadores desea agregar (valor numerico entero): "))
        for i in range(jugadores_ingresar):
            jugador = {}
            nombre = input("ingrese el nombre del jugador: ")
            ranking_mundial = float(input("ingrese el ranking del jugador (valor flotante): "))
            servicio = float(input("ingrese la estadistica de servicio (solo se aceptan valores flotantes): "))
            reves = float(input("ingrese la estadistica de reves (solo se aceptan valores flotantes): "))
            volea = float(input("ingrese la estadistica de volea(solo se aceptan valores flotantes): ")) 
            movimiento = float(input("ingrese la estadistica de movimiento(solo se aceptan valores flotantes): "))  
            condicion_fisica = input("cual es su condicion fisica?: ")

            jugador[nombre] = {
                "ranking mundial": ranking_mundial,
                "servicio" : servicio,
                "reves": reves,
                "volea": volea,
                "movimiento": movimiento,
                "condicion fisica": condicion_fisica
            }
            equipo2.append(jugador)
            jugadores.append(jugador)
            return equipo2, jugadores

#3. Mostrar información de los jugadores: 3
#a. Imprimir la información detallada de todos los jugadores registrados en el sistema.
def mostrar_info(equipo1,equipo2):
    print("""
1 = mostrar info de los jugadores del equipo 1
2 = mostrar info de los jugadores en el equipo 2
3 = mostrar info de todos los jugadores
""")
    opcion = input("de cual equipo quiere mostrar informacion el jugador?: ")
    if opcion == "1":
        for jugador in equipo1:
            print(f"jugador de equipo 1: ")
            print(jugador)
    elif opcion == "2":
        for jugador in equipo2:
            print(f"jugador de equipo 2: ")
            print(jugador)
    elif opcion == "3":
        for jugador in jugadores:
            print(jugador)

#4. Obtener una lista solo de los jugadores: 4
#    a. Mostrar una lista con los nombres de todos los jugadores registrados en el sistema.
def mostrar_lista_jugadores(jugadores):
    for jugador in jugadores:
        print(jugador)

#5. Eliminar un jugador específico:5
#    a. Permitir al usuario eliminar un jugador específico de la lista de jugadores, ingresando el
#    nombre del jugador.
def eliminar_jugador():
    nombre_a_remover = input("¿Qué jugador desea remover?: ")
    for jugador in jugadores:
        if nombre_a_remover in jugador:
            jugadores.remove(jugador)
            print(f"Jugador {nombre_a_remover} eliminado.")
            break
    else:
        print(f"No se encontró el jugador {nombre_a_remover}.")
#6. Gestionar partidos (Jugador 1-Jugador 2-Fecha del partido): 6
#    a. Permitir al usuario registrar, mostrar y actualizar la información de los partidos, incluyendo los
#    jugadores, fecha, sede y resultado.
partido_organizados = []
equipos_existentes = {
    "equipo 1": equipo1,
    "equipo 2": equipo2
}
def organizar_partido():
    print("""
1 = organizar partido
2 = subir informacion de resultados
""")
    opcion = opcion = input("ingrese una opcion: ")
    if opcion == "1":    
        partido ={}
        partido_nombre = input("ingrese nombre del partido (ejemplo: equipo1 vs equipo2): ")
        fecha = input("ingrese una fecha en el siguiente formato dd/mm/año: ")
        sede =input("ingrese la sede que se jugara: ")
        resultado = input("ingrese el resultado del partido:")

        partido[partido_nombre] = {
            "equipos involucrados": equipos_existentes,
            "fecha": fecha,
            "sede": sede,
            "resultado": resultado
        }
        partido_organizados.append(partido)
        return partido_organizados
    if opcion == "2":
        partido["resultado"] = input("ingrese el resultado del partido:")
        partido.update("resultado")
        print(partido)
#1. Mostrar menú interactivo de opciones:
#    a. Desplegar un menú con las diferentes opciones disponibles en el sistema. 7
while True:
    print("""
1 = agregar jugador
2 = mostrar informacion de los jugadores
3 = mostrar lista de los jugadores
4 = eliminar jugador
5 = organizar partido
6 = salir        
""")
    opcion = input("ingrese una opcion: ")
    if opcion == "1":
        agregar_jugador(equipo1,equipo2)
        print("agregado correctamente")
    elif opcion == "2":
        mostrar_info(equipo1,equipo2)
    elif opcion == "3":
        mostrar_lista_jugadores(jugadores)
    elif opcion == "4":
        eliminar_jugador(equipo1,equipo2)
    elif opcion == "5":
        organizar_partido()
    elif opcion =="6":
        print("""
cerrando sesion .........
.............
......
""")
        break
