jugadores = []

def agregar_jugador():
    jugador = {}
    nombre = input("Ingrese el nombre del jugador: ")
    ranking_mundial = float(input("Ingrese el ranking del jugador (valor flotante): "))
    servicio = float(input("Ingrese la estadística de servicio (solo se aceptan valores flotantes): "))
    reves = float(input("Ingrese la estadística de revés (solo se aceptan valores flotantes): "))
    volea = float(input("Ingrese la estadística de volea (solo se aceptan valores flotantes): ")) 
    movimiento = float(input("Ingrese la estadística de movimiento (solo se aceptan valores flotantes): "))  
    condicion_fisica = input("¿Cuál es su condición física?: ")

    jugador[nombre] = {
        "ranking mundial": ranking_mundial,
        "servicio": servicio,
        "reves": reves,
        "volea": volea,
        "movimiento": movimiento,
        "condicion fisica": condicion_fisica
    }
    jugadores.append(jugador)
    return jugadores

def mostrar_info(jugadores):
    for jugador in jugadores:
        print(f"Nombre: {list(jugador.keys())[0]}")
        detalles = jugador[list(jugador.keys())[0]]
        print(f"  Ranking mundial: {detalles['ranking mundial']}")
        print(f"  Servicio: {detalles['servicio']}")
        print(f"  Revés: {detalles['reves']}")
        print(f"  Volea: {detalles['volea']}")
        print(f"  Movimiento: {detalles['movimiento']}")
        print(f"  Condición física: {detalles['condicion fisica']}")

def mostrar_lista_jugadores(jugadores):
    for jugador in jugadores:
        print(list(jugador.keys())[0])

def eliminar_jugador():
    nombre_a_remover = input("¿Qué jugador desea remover?: ")
    for jugador in jugadores:
        if nombre_a_remover in jugador:
            jugadores.remove(jugador)
            print(f"Jugador {nombre_a_remover} eliminado.")
            break
    else:
        print(f"No se encontró el jugador {nombre_a_remover}.")

partido_organizados = []

def organizar_partido():
    print("""
1 = organizar partido
2 = subir informacion de resultados
""")
    opcion = input("Ingrese una opción: ")
    if opcion == "1":
        partido = {}
        partido_nombre = input("Ingrese nombre del partido (ejemplo: equipo1 vs equipo2): ")
        print("Jugadores disponibles:")
        for i, jugador in enumerate(jugadores):
            print(f"{i + 1}. {list(jugador.keys())[0]}")
        
        jugador1_index = int(input("Seleccione el jugador 1 (ingrese el número): ")) - 1
        jugador2_index = int(input("Seleccione el jugador 2 (ingrese el número): ")) - 1
        
        partido[partido_nombre] = {
            "jugador 1": jugadores[jugador1_index],
            "jugador 2": jugadores[jugador2_index],
            "fecha": input("Ingrese una fecha en el siguiente formato dd/mm/año: "),
            "sede": input("Ingrese la sede donde se jugará: "),
            "resultado": ""
        }
        partido_organizados.append(partido)
        print("Partido organizado correctamente.")

    elif opcion == "2":
        partido_nombre = input("Ingrese el nombre del partido: ")
        resultado = input("Ingrese el resultado del partido: ")
        for partido in partido_organizados:
            if partido_nombre in partido:
                partido[partido_nombre]["resultado"] = resultado
                print("Resultado actualizado correctamente.")
                break
        else:
            print(f"No se encontró el partido {partido_nombre}.")

while True:
    print("""
1 = Agregar jugador
2 = Mostrar información de los jugadores
3 = Mostrar lista de los jugadores
4 = Eliminar jugador
5 = Organizar partido
6 = Salir
""")
    opcion = input("Ingrese una opción: ")
    if opcion == "1":
        agregar_jugador()
        print("Jugador agregado correctamente.")
    elif opcion == "2":
        mostrar_info(jugadores)
   
