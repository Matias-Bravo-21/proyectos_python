#2. Agregar nuevo jugador: 1
#    a. Diccionario: Permitir al usuario ingresar la información de un nuevo jugador, incluyendo
#    nombre, ranking mundial, servicio, revés, volea, movimiento y condición física. (Estos
#    valores deben ser flotantes)
#    b. Lista: Almacenar la información del nuevo jugador en una lista. 2
jugadores_MABF = []
def agregar_jugador():
    jugador_MABF = {}
    nombre_MABF = input("ingrese el nombre del jugador: ")
    ranking_mundial_MABF = float(input("ingrese el ranking del jugador (valor flotante): "))
    servicio_MABF = float(input("ingrese la estadistica de servicio (solo se aceptan valores flotantes): "))
    reves_MABF = float(input("ingrese la estadistica de reves (solo se aceptan valores flotantes): "))
    volea_MABF = float(input("ingrese la estadistica de volea(solo se aceptan valores flotantes): ")) 
    movimiento_MABF = float(input("ingrese la estadistica de movimiento(solo se aceptan valores flotantes): "))  
    condicion_fisica_MABF = input("cual es su condicion fisica?: ")

    jugador_MABF[nombre_MABF] = {
        "ranking mundial": ranking_mundial_MABF,
        "servicio" : servicio_MABF,
        "reves": reves_MABF,
        "volea": volea_MABF,
        "movimiento": movimiento_MABF,
        "condicion fisica": condicion_fisica_MABF
    }
    jugadores_MABF.append(jugador_MABF)
    return jugadores_MABF
#3. Mostrar información de los jugadores: 3
#a. Imprimir la información detallada de todos los jugadores registrados en el sistema.
def mostrar_info(jugadores_MABF):
    for jugador_MABF in jugadores_MABF:
        print(f"Nombre: {list(jugador_MABF.keys())[0]}")
        detalles_MABF = jugador_MABF[list(jugador_MABF.keys())[0]]
        print(f"  Ranking mundial: {detalles_MABF['ranking mundial']}")
        print(f"  Servicio: {detalles_MABF['servicio']}")
        print(f"  Revés: {detalles_MABF['reves']}")
        print(f"  Volea: {detalles_MABF['volea']}")
        print(f"  Movimiento: {detalles_MABF['movimiento']}")
        print(f"  Condición física: {detalles_MABF['condicion fisica']}")

#4. Obtener una lista solo de los jugadores: 4
#    a. Mostrar una lista con los nombres de todos los jugadores registrados en el sistema.
def mostrar_lista_jugadores(jugadores_MABF):
    for jugador_MABF in jugadores_MABF:
        print(jugador_MABF)

#5. Eliminar un jugador específico:5
#    a. Permitir al usuario eliminar un jugador específico de la lista de jugadores, ingresando el
#    nombre del jugador.
def eliminar_jugador():
    nombre_a_remover_MABF = input("que jugador desea remover?: ")
    if nombre_a_remover_MABF in jugadores_MABF:
        jugadores_MABF.pop()
        print(f"jugador {nombre_a_remover_MABF} eliminado.")
    else:
        print(f"no se encontró el jugador {nombre_a_remover_MABF}.")
#6. Gestionar partidos (Jugador 1-Jugador 2-Fecha del partido): 6
#    a. Permitir al usuario registrar, mostrar y actualizar la información de los partidos, incluyendo los
#    jugadores, fecha, sede y resultado.
partido_organizados_MABF = []
def organizar_partido():
    print("""
1 = organizar partido
2 = subir informacion de resultados
""")
    opcion_MABF = input("ingrese una opcion: ")
    if opcion_MABF == "1":    
        partido_MABF ={}
        partido_nombre_MABF = input("ingrese nombre del partido (ejemplo: equipo1 vs equipo2): ")
        fecha_MABF = input("ingrese una fecha en el siguiente formato dd/mm/año: ")
        sede_MABF =input("ingrese la sede que se jugara: ")
        resultado_MABF = input("ingrese el resultado del partido:")

        partido_MABF[partido_nombre_MABF] = {
            "fecha": fecha_MABF,
            "sede": sede_MABF,
            "resultado": resultado_MABF
        }
        partido_organizados_MABF.append(partido_MABF)
        return partido_organizados_MABF
    if opcion_MABF == "2":
        partido_MABF["resultado"] = input("ingrese el resultado del partido:")
        partido_MABF.update("resultado")
        print(partido_MABF)
#1. Mostrar menú interactivo de opciones:
#    a. Desplegar un menú con las diferentes opciones disponibles en el sistema. 7
while True:
    print("""
1 = agregar jugador
2 = mostrar informacion de los jugadores
3 = mostrar lista de los jugadores
4 = eliminar jugador
5 = organizar partido
6 = salir        
""")
    opcion_MABF = input("ingrese una opcion: ")
    if opcion_MABF == "1":
        agregar_jugador()
        print("agregado correctamente")
    elif opcion_MABF == "2":
        mostrar_info(jugadores_MABF)
    elif opcion_MABF == "3":
        mostrar_lista_jugadores(jugadores_MABF)
    elif opcion_MABF == "4":
        print(jugadores_MABF)
        eliminar_jugador()
    elif opcion_MABF == "5":
        organizar_partido()
        print(partido_organizados_MABF)
    elif opcion_MABF =="6":
        print("""
cerrando sesion .........
.............
......
""")
        break
